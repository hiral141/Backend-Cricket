<?php
include("config.php");
if(isset($_POST['save']))
{
$tname = $_POST['tname'];
$tcode = $_POST['tcode'];
$players = $_POST['players'];
$country = $_POST['country'];
$sql_query = "INSERT INTO team (tname ,tcode,country,players) VALUES ('$tname','$tcode','$country','$players')";
$result = mysqli_query($conn, $sql_query);
if($result)
{
    echo "sucess";
}
else
{
    echo "fail";
}
}
?>