<?php
include('config.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Profile</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
   body{
  font-family: arial;
  background: #b2bec3;
  padding:0;
  margin: 0;
}
.center{
  text-align: center;
}
#main{
  width: 800px;
  margin: 0 auto;
  background: white;
  font-size: 19px;
}
#header{
  background: ##ADD8E6;
}
h1{
  float: left;
  margin: 15px;
}
#table-form{
  background: #ADD8E6;
  padding: 20px 10px;
}
#table-form input[type="text"]{
  height: 25px;
  font-size: 18px;
  padding: 3px 10px;
  margin-right: 17px;
  border-radius: 4px;
  border: 1px solid #5D3F6A;
  outline: 0;
}
#save-button,
#table-data{
  padding: 15px;
  height: 500px;
  vertical-align: top;
}
#table-data th{
  background: #808080;
  color: #fff;
}
#table-data tr:nth-child(odd){
  background: #ecf0f1;
}
#table-data h2{
  text-align: center;
}
   </style>
</head>
<body>
    <!-- ======= Header ======= -->
    <header id="header">
      <div class="container">
  
        <div class="logo float-left">
          <h1 class="text-light"><a href="index.html"><span>Cricket Tournament</span></a></h1>
        </div>
        <nav class="nav-menu float-left d-none d-lg-block">
          <ul>
            <li class="active"><a href="index.html">Home</a></li>
            <li><a href="index.php">About Us</a></li>
            <li><a href="index.php">Countries</a></li>
            <li><a href="index.php">Venue</a></li>
            <li class="drop-down"><a href="">Team</a>
              <ul>
                <li><a href="team.php">Profile</a></li>
              </ul>
            </li>
            <li class="drop-down"><a href="">Players</a>
              <ul>
                <li><a href="player.php">Profile</a></li>
              </ul>
            </li>
            <li class="drop-down"><a href="">Matches</a>
              <ul>
                <li><a href="MatchList.php">List Of Matches</a></li>
                <li ><a href="MatchSummary.php">Match Summary</a></li>
                </li>
              </ul>
            </li>
            <li><a href ="table.php">Tournament Score Table</a></li>
            <li><a href ="result.php">Results</a></li>
          </ul>
        </nav><!-- .nav-menu -->
  
      </div>
    </header><!-- End Header -->
  
    <main id="main">
      <!-- ======= Breadcrumbs Section ======= -->
      <section class="breadcrumbs">
        <div class="container">
          <div class="d-flex justify-content-between align-items-center">
            <h2>Player Profile</h2>
            <ol>
              <li><a href="index.html">Home</a></li>
              <li> Player Profile</li>
            </ol>
          </div>
        </div>
      </section><!-- End Breadcrumbs Section -->
  
      <section class="inner-page">
      <table id="main" border="0" cellspacing="0">
    <tr>
      <td id="header">
        <h1>Player's Registration</h1>
      </td>
    </tr>
    <tr>
      <td id="table-form">
        <form id="addForm" action ="player_entry.php" method ="POST">
          Name : <input type="text" name="pname" id="pname">
          Gender : <input type="text" name="pgender" id="pgender"></br></br>
          Country : <input type="text" name="pcountry" id="pcountry">
          Role: <input type="text" name="prole" id="prole"></br></br>
          <input type ="submit" name ="save" value="Submit" style ="font-size:20px">
        </form>
      </td>
    </tr>
    <tr>
      <td id="table-data">
        <table width="100%" cellpadding="10px" >
        <?php
        $result = mysqli_query($conn, "SELECT * from players ORDER by pname DESC ");
        while($res = mysqli_fetch_array($result))
        {
            echo "<tr>";
            echo "<td>".$res['pname']."</td>";
            echo "<td>".$res['pgender']."</td>";
            echo "<td>".$res['pcountry']."</td>"; 
            echo "<td>".$res['prole']."</td>"; 
            echo "</tr>";
        }
        ?>
        </table>
      </td>
    </tr>
  </table>
  </div>
        </div>
      </section>
    </main><!-- End #main -->
  </body>
  </html>