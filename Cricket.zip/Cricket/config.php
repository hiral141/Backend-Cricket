<?php
$server_name="localhost";
$username ="root";
$password ="root";
$database_name ="cricket";
$conn = mysqli_connect($server_name,$username,$password ,$database_name );
if (!$conn)
{
    die("Connection Failed:" . mysqli_connect_error());
}
