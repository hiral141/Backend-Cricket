<?php
include('config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Result</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
    th, td, p, input, h3 {
        font:15px 'Times New Roman';
        margin:20px;
    }
    table, th, td {
        border: solid 1px rgb(166, 159, 197);
        border-collapse: collapse;
        padding: 8px;
        text-align: center;
        margin-left:auto;
        margin-right:auto;
    }
    th {
        font-weight:bold;
    }
  .button {
  background-color: #62658d; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}
.block {
  display: block;
  width: 100%;
  border: none;
  background-color: #a6a8b4;
  padding: 14px 28px;
  font-size: 16px;
  cursor: pointer;
  text-align: center;
}
    </style>
</head>
<body>
    <!-- ======= Header ======= -->
    <header id="header">
      <div class="container">
  
        <div class="logo float-left">
          <h1 class="text-light"><a href="index.php"><span>Cricket Tournament</span></a></h1>
        </div>
        <nav class="nav-menu float-left d-none d-lg-block">
          <ul>
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="index.php">About Us</a></li>
            <li><a href="index.php">Countries</a></li>
            <li><a href="index.php">Venue</a></li>
            <li class="drop-down"><a href="">Team</a>
              <ul>
                <li><a href="team.php">Profile</a></li>
              </ul>
            </li>
            <li class="drop-down"><a href="">Players</a>
              <ul>
                <li><a href="player.php">Profile</a></li>
              </ul>
            </li>
            <li class="drop-down"><a href="">Matches</a>
              <ul>
                <li><a href="MatchList.php">List Of Matches</a></li>
                <li ><a href="MatchSummary.php">Match Summary</a>
                </li>
              </ul>
            </li>
           
            <li><a href ="table.php">Tournament Score Table</a></li>
            <li><a href ="result.php">Results</a></li>
          </ul>
        </nav><!-- .nav-menu -->
  
      </div>
    </header><!-- End Header -->
  
    <main id="main">
      <!-- ======= Breadcrumbs Section ======= -->
      <section class="breadcrumbs">
        <div class="container">
          <div class="d-flex justify-content-between align-items-center">
            <h2>Result</h2>
            <ol>
              <li><a href="index.php">Home</a></li>
              <li>Result</li>
            </ol>
          </div>
        </div>
      </section><!-- End Breadcrumbs Section -->
  
      <section class="inner-page">
        <div class="container">
        <table align="center" border="1px" width="50%"  cellpadding ="5" cellspacing ="5" class="table-striped border-success" id="abc"> 
	<tr> 
		<h2 align ="center">Result</h2></th> 
		</tr> 
			 
			  <th> Matches </th> 
			   <th> No of Sixes </th>
         <th> No of Four </th>
         <th> Statistic </th>
		</tr> 
        <?php 
        $result=mysqli_query($conn,"select * from result"); 
        while($row=mysqli_fetch_assoc($result)) 
		{ 
		?> 
		<td><?php echo $row['matches']; ?></td> 
    <td><?php echo $row['sixes']; ?></td> 
    <td><?php echo $row['foures']; ?></td> 
    <td><?php echo '<img src ="data:image;base64,'.base64_encode($row['statistic']).'" alt="Image" style ="width :100px; height: 100px;">' ?></td>
		</tr> 
	<?php 
               } 
          ?> 

	</table> 
        </table>     
            </div>
              </div>
              </div>
              </div>
            </section>
    </main><!-- End #main -->
  </body>
  </html>