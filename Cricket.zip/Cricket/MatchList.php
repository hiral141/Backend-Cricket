<?php
include('config.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Match List</title>
  <meta content="" name="description">
  <meta content="" name="keywords">
  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <style>
    #abc{
    font-family: Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
  }
  
  #abc td, #abc th {
    border: 1px solid #ddd;
    padding: 8px;
  }
  
  #abc tr:nth-child(even){background-color: #e7dede;}
  
  #abc tr:hover {background-color: rgb(234, 239, 240);}
  
  #abc th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #97a9c4;
    color: white;
  }
    </style>
</head>
<body>
    <!-- ======= Header ======= -->
    <header id="header">
      <div class="container">
  
        <div class="logo float-left">
          <h1 class="text-light"><a href="index.php"><span>Cricket Tournament</span></a></h1>
        </div>
        <nav class="nav-menu float-left d-none d-lg-block">
          <ul>
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="index.php">About Us</a></li>
            <li><a href="countries.php">Countries</a></li>
            <li><a href="venue.php">Venue</a></li>
            <li class="drop-down"><a href="">Team</a>
              <ul>
                <li><a href="team.php">Profile</a></li>
              </ul>
            </li>
            <li class="drop-down"><a href="">Players</a>
              <ul>
                <li><a href="player.php">Profile</a></li>
              </ul>
            </li>
            <li class="drop-down"><a href="">Matches</a>
              <ul>
                <li><a href="MatchList.php">List Of Matches</a></li>
                <li ><a href="MatchSummary.php">Match Summary</a>
                </li>
              </ul>
            </li>
            
            <li><a href ="table.php">Tournament Score Table</a></li>
            <li><a href ="result.php">Results</a></li>
          </ul>
        </nav><!-- .nav-menu -->
  
      </div>
    </header><!-- End Header -->
  
    <main id="main">
      <!-- ======= Breadcrumbs Section ======= -->
      <section class="breadcrumbs">
        <div class="container">
          <div class="d-flex justify-content-between align-items-center">
            <h2>Match List</h2>
            <ol>
              <li><a href="index.php">Home</a></li>
              <li> Match List</li>
            </ol>
          </div>
        </div>
      </section><!-- End Breadcrumbs Section -->
  
      <section class="inner-page">
        <div class="container">
        </div>
      <table align="center" border="1px"   cellpadding ="5" cellspacing ="5" class="table-striped border-success" id="abc"> 
	<tr> 
		<h2 align ="center">Match List For the Tournament</h2></th> 
		</tr> 
			  <th> ID </th> 
			  <th> Date </th> 
			   <th> Match </th>
         <th> Time </th>
         <th> Venue </th>
		</tr> 
        <?php 
        $result=mysqli_query($conn,"select * from matchlist"); 
        while($rows=mysqli_fetch_assoc($result)) 
		{ 
		?> 
		<tr> <td><?php echo $rows['mid']; ?></td> 
		<td><?php echo $rows['date']; ?></td> 
    <td><?php echo $rows['match']; ?></td> 
    <td><?php echo $rows['time']; ?></td> 
    <td><?php echo $rows['venue']; ?></td> 
		</tr> 
	<?php 
               } 
          ?> 

	</table> 
                </table> 
            </div> 
        </div>
      </section>
  
    </main><!-- End #main -->
  
  
  </body>
  
  </html>