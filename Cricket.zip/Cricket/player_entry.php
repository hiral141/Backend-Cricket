<?php 
include("config.php");
if(isset($_POST['save']))
{
    $pname = $_POST['pname'];
    $pgender = $_POST['pgender'];
    $prole = $_POST['prole'];
    $pcountry = $_POST['pcountry'];
    $sql_query = "INSERT INTO players (pname ,pgender,prole,pcountry) VALUES ('$pname','$pgender','$prole','$pcountry')";
    $result = mysqli_query($conn, $sql_query);
    if($result)
    {
        echo "sucess";
    }
    else
    {
        echo "fail";
    }
    mysqli_close($conn);
}
?>